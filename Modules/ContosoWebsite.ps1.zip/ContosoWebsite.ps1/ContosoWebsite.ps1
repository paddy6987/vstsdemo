Configuration ContosoWebsite
{
 
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
    # The second resource block ensures that the website content copied to the website root folder.
    File WebsiteContent
    {
            Ensure = 'Present'
            SourcePath = 'https://raw.githubusercontent.com/paddy6987/tower/master/index.html'
            DestinationPath = 'c:\inetpub\wwwroot'
    }  
  }
} 